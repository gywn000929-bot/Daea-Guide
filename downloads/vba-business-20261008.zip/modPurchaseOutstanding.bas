Attribute VB_Name = "modPurchaseOutstanding"
Option Explicit

Public Sub ���ֹ̳�_����()

    Dim ws As Worksheet, resWs As Worksheet
    Dim wb As Workbook
    Dim dict As Object
    Dim lastRow As Long, i As Long, rowIdx As Long
    Dim customerCode As String, factory As String
    Dim itemCode As String, itemName As String
    Dim qty As Double, totalQty As Double
    Dim key As String, k As Variant, data As Variant
    Dim pass As Long
    Dim baseName As String, sheetName As String
    Dim suffix As Long
    Dim sh As Object, nameExists As Boolean

    Dim headerRow As Long, cols As Variant
    On Error GoTo Failed

    If TypeName(ActiveSheet) <> "Worksheet" Then
        MsgBox "���ֹ̳� ���� ��Ʈ�� �������ּ���.", vbExclamation
        Exit Sub
    End If

    Set ws = ActiveSheet
    Set wb = ws.Parent

    If Not FindHeaders(ws, Array("���ֹ�ȣ", "����ó ǰ���ڵ�", "ǰ���", "�̳�����"), headerRow, cols) Then
        Err.Raise vbObjectError + 700, , "���� �̳� ���� ��Ʈ�� �����ϼ���. �ʿ��� �Ӹ���: ���ֹ�ȣ/����ó ǰ���ڵ�/ǰ���/�̳�����"
    End If

    lastRow = Application.Max( _
        ws.Cells(ws.Rows.Count, cols(2)).End(xlUp).Row, _
        ws.Cells(ws.Rows.Count, cols(1)).End(xlUp).Row, _
        ws.Cells(ws.Rows.Count, cols(0)).End(xlUp).Row, _
        ws.Cells(ws.Rows.Count, cols(3)).End(xlUp).Row)

    If lastRow < 2 Then
        MsgBox "������ �����Ͱ� �����ϴ�.", vbInformation
        Exit Sub
    End If

    Set dict = CreateObject("Scripting.Dictionary")

    For i = headerRow + 1 To lastRow

        If IsError(ws.Cells(i, cols(0)).Value2) Or _
           IsError(ws.Cells(i, cols(1)).Value2) Or _
           IsError(ws.Cells(i, cols(2)).Value2) Then

            Err.Raise vbObjectError + 701, , _
                "���塤ǰ���ڵ塤ǰ����� ���� ���� �ֽ��ϴ�. ��: " & i
        End If

        customerCode = Trim(CStr(ws.Cells(i, cols(0)).Value2))
        itemCode = Trim(CStr(ws.Cells(i, cols(1)).Value2))
        itemName = Trim(CStr(ws.Cells(i, cols(2)).Value2))

        If customerCode = "" And itemCode = "" And itemName = "" Then
            If InStr(1, CStr(ws.Cells(i, 4).Value2), "�հ�", vbTextCompare) > 0 Then GoTo NextRow
        End If
        ' ���� ������ �հ��� ����
        If customerCode = "" And itemCode = "" Then
            Select Case UCase(itemName)
                Case "�հ�", "�� �հ�", "���հ�", "��", "TOTAL"
                    GoTo NextRow
            End Select
        End If

        ' ������ �� �� ����
        If customerCode = "" And itemCode = "" And itemName = "" Then
            If Not IsError(ws.Cells(i, cols(3)).Value2) Then
                If Len(Trim(CStr(ws.Cells(i, cols(3)).Value2))) = 0 Then
                    GoTo NextRow
                End If
            End If
        End If

        If IsError(ws.Cells(i, cols(3)).Value2) Then
            Err.Raise vbObjectError + 702, , _
                "�̳������� ���� ���� �ֽ��ϴ�. ��: " & i
        End If

        If Not IsNumeric(ws.Cells(i, cols(3)).Value2) Then
            Err.Raise vbObjectError + 703, , _
                "�̳������� ���ڰ� �ƴմϴ�. ��: " & i
        End If

        If itemCode = "" And itemName = "" Then
            Err.Raise vbObjectError + 704, , _
                "������ ������ ǰ���ڵ�� ǰ����� �����ϴ�. ��: " & i
        End If

        ' ���ֹ�ȣ ���ڸ� F1/F2/F5�� ���� ����
        Select Case UCase$(Left$(customerCode, 2))
            Case "F1": factory = "F1"
            Case "F2": factory = "F2"
            Case "F5": factory = "F5"
            Case Else
                Err.Raise vbObjectError + 705, , "���ֹ�ȣ���� ������ ������ �� �����ϴ�. ��: " & i & " / " & customerCode
        End Select

        qty = CDbl(ws.Cells(i, cols(3)).Value2)

        ' ���� + ǰ���ڵ� + ǰ��� ���� ����
        key = Len(factory) & ":" & factory & _
              Len(itemCode) & ":" & itemCode & itemName

        If dict.Exists(key) Then
            data = dict(key)
            data(3) = data(3) + qty
            dict(key) = data
        Else
            dict.Add key, Array(factory, itemCode, itemName, qty)
        End If

        totalQty = totalQty + qty

NextRow:
    Next i

    If dict.Count = 0 Then
        MsgBox "������ �� �����Ͱ� �����ϴ�.", vbInformation
        Exit Sub
    End If

    ' ��� ��Ʈ �̸� �ߺ� ����
    baseName = "���ֹ̳�_����_" & Format(Now, "hhmmss")
    sheetName = baseName

    Do
        nameExists = False

        For Each sh In wb.Sheets
            If StrComp(sh.Name, sheetName, vbTextCompare) = 0 Then
                nameExists = True
                Exit For
            End If
        Next sh

        If Not nameExists Then Exit Do

        suffix = suffix + 1
        sheetName = baseName & "_" & suffix
    Loop

    Set resWs = wb.Worksheets.Add(After:=wb.Sheets(wb.Sheets.Count))
    resWs.Name = sheetName

    resWs.Range("A1:D1").Value = _
        Array("FAC", "����ó ǰ���ڵ�", "ǰ���", "�̳��ܷ�")

    resWs.Columns("B:C").NumberFormat = "@"
    rowIdx = 2

    ' ǰ���ڵ尡 ���� �׸� ���� ���
    For pass = 1 To 2
        For Each k In dict.Keys

            data = dict(k)

            If (pass = 1 And data(1) = "") Or _
               (pass = 2 And data(1) <> "") Then

                resWs.Cells(rowIdx, 1).Value2 = data(0)
                resWs.Cells(rowIdx, 2).Value2 = data(1)
                resWs.Cells(rowIdx, 3).Value2 = data(2)
                resWs.Cells(rowIdx, 4).Value2 = data(3)

                rowIdx = rowIdx + 1
            End If

        Next k
    Next pass

    If rowIdx > 3 Then
        resWs.Range("A1:D" & rowIdx - 1).Sort Key1:=resWs.Range("A2"), Order1:=xlAscending, Key2:=resWs.Range("B2"), Order2:=xlAscending, Key3:=resWs.Range("C2"), Order3:=xlAscending, Header:=xlYes
    End If
    resWs.Cells(rowIdx, 3).Value2 = "TOTAL"
    resWs.Cells(rowIdx, 4).Value2 = totalQty

    With resWs.Range("A1:D" & rowIdx)
        .Font.Name = "Arial"
        .Font.Size = 9
        .Font.Color = vbBlack
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Weight = xlThin
        .Borders.Color = RGB(200, 200, 200)
        .RowHeight = 18
    End With

    With resWs.Range("A1:D1")
        .Font.Bold = True
        .Interior.Color = RGB(221, 235, 247)
        .HorizontalAlignment = xlCenter
        .RowHeight = 24
    End With

    With resWs.Range("A" & rowIdx & ":D" & rowIdx)
        .Font.Bold = True
        .Interior.Color = RGB(221, 235, 247)
    End With

    resWs.Range("D2:D" & rowIdx).NumberFormat = "#,##0"
    resWs.Columns("A").HorizontalAlignment = xlCenter
    resWs.Columns("A:D").AutoFit

    If resWs.Columns("A").ColumnWidth < 8 Then _
        resWs.Columns("A").ColumnWidth = 8

    If resWs.Columns("B").ColumnWidth < 20 Then _
        resWs.Columns("B").ColumnWidth = 20

    If resWs.Columns("C").ColumnWidth < 28 Then _
        resWs.Columns("C").ColumnWidth = 28

    If resWs.Columns("D").ColumnWidth < 16 Then _
        resWs.Columns("D").ColumnWidth = 16

    MsgBox "���ֹ̳� �������� �Ϸ�" & vbCrLf & _
           "�� �̳�����: " & Format(totalQty, "#,##0"), vbInformation
    Exit Sub

Failed:
    MsgBox Err.Description, vbExclamation

End Sub

Private Function HKey(ByVal v As Variant) As String
    If IsError(v) Then Exit Function
    Dim s As String
    s = UCase$(Trim$(CStr(v)))
    s = Replace(s, " ", "")
    s = Replace(s, ChrW(160), "")
    s = Replace(s, vbCr, "")
    s = Replace(s, vbLf, "")
    s = Replace(s, vbTab, "")
    s = Replace(s, "��", "")
    s = Replace(s, "��", "")
    HKey = s
End Function
Private Function FindHeaders(ByVal ws As Worksheet, ByVal labels As Variant, ByRef hr As Long, ByRef cols As Variant) As Boolean
    Dim r As Long, c As Long, j As Long, n As Long, hits As Long, found() As Long
    n = UBound(labels) - LBound(labels) + 1
    For r = 1 To 10
        ReDim found(0 To n - 1)
        For c = 1 To ws.Cells(r, ws.Columns.Count).End(xlToLeft).Column
            For j = 0 To n - 1
                If HKey(ws.Cells(r, c).Value2) = HKey(labels(j)) Then found(j) = c
            Next j
        Next c
        hits = 0
        For j = 0 To n - 1
            If found(j) > 0 Then hits = hits + 1
        Next j
        If hits = n Then
            hr = r: cols = found: FindHeaders = True: Exit Function
        End If
    Next r
End Function
Private Function NewSheetName(ByVal wb As Workbook, ByVal base As String) As String
    Dim s As String, i As Long, sh As Object, exists As Boolean
    s = base
    Do
        exists = False
        For Each sh In wb.Sheets
            If StrComp(sh.Name, s, vbTextCompare) = 0 Then exists = True: Exit For
        Next sh
        If Not exists Then NewSheetName = s: Exit Function
        i = i + 1: s = base & "_" & i
    Loop
End Function
