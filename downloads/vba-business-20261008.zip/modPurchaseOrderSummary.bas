Attribute VB_Name = "modPurchaseOrderSummary"
Option Explicit

Public Sub �����ܷ�_���ֺ�_����()
    Dim ws As Worksheet, wb As Workbook, outWs As Worksheet
    Dim labels As Variant, cols(0 To 4) As Long, hr As Long
    Dim r As Long, c As Long, j As Long, hits As Long, lastRow As Long, n As Long
    Dim po As String, shortPO As String, orderNo As String, item As String, key As String
    Dim dict As Object, poMap As Object, data As Variant, k As Variant
    Dim q As Double, bal As Double, totalQ As Double, totalBal As Double
    Dim baseName As String, outName As String, suffix As Long, sh As Object, exists As Boolean
    On Error GoTo Failed
    If TypeName(ActiveSheet) <> "Worksheet" Then Err.Raise vbObjectError + 801, , "�����ܷ� ���� ��Ʈ�� �����ϼ���."
    Set ws = ActiveSheet
    Set wb = ws.Parent
    labels = Array("���ֹ�ȣ", "���ֹ�ȣ", "ǰ���", "���ּ���", "�̳�����")
    For r = 1 To 10
        Erase cols
        For c = 1 To ws.Cells(r, ws.Columns.Count).End(xlToLeft).Column
            For j = 0 To 4
                If HeaderKey(ws.Cells(r, c).Value2) = labels(j) Then cols(j) = c
            Next j
        Next c
        hits = 0
        For j = 0 To 4
            If cols(j) > 0 Then hits = hits + 1
        Next j
        If hits = 5 Then hr = r: Exit For
    Next r
    If hr = 0 Then Err.Raise vbObjectError + 802, , "���ֹ�ȣ / ���ֹ�ȣ / ǰ��� / ���ּ��� / �̳����� �Ӹ����� ã�� ���߽��ϴ�. ���� ��Ʈ���� �����ϼ���."
    For j = 0 To 4
        n = ws.Cells(ws.Rows.Count, cols(j)).End(xlUp).Row
        If n > lastRow Then lastRow = n
    Next j
    Set dict = CreateObject("Scripting.Dictionary")
    Set poMap = CreateObject("Scripting.Dictionary")
    For r = hr + 1 To lastRow
        po = TextValue(ws.Cells(r, cols(0)).Value2, r)
        orderNo = TextValue(ws.Cells(r, cols(1)).Value2, r)
        item = TextValue(ws.Cells(r, cols(2)).Value2, r)
        If po = "" And orderNo = "" Then
            If IsTotalRow(ws, r) Then GoTo NextRow
            If item = "" And Len(TextValue(ws.Cells(r, cols(3)).Value2, r)) = 0 And Len(TextValue(ws.Cells(r, cols(4)).Value2, r)) = 0 Then GoTo NextRow
        End If
        If Len(po) < 5 Or item = "" Then Err.Raise vbObjectError + 803, , "���ֹ�ȣ �Ǵ� ǰ����� ��� �ְų� ���ֹ�ȣ�� 5�ڸ� �̸��Դϴ�. ���� ��: " & r
        shortPO = Right$(po, 5)
        If poMap.Exists(shortPO) Then
            If poMap(shortPO) <> po Then Err.Raise vbObjectError + 804, , "���� �ٸ� ���ֹ�ȣ�� �� 5�ڸ��� �����ϴ�: " & poMap(shortPO) & " / " & po & ". ������ Ȯ�����ּ���."
        Else
            poMap.Add shortPO, po
        End If
        q = QuantityValue(ws.Cells(r, cols(3)).Value2, r)
        bal = QuantityValue(ws.Cells(r, cols(4)).Value2, r)
        key = Len(shortPO) & ":" & shortPO & Len(orderNo) & ":" & orderNo & Len(item) & ":" & item
        If dict.Exists(key) Then
            data = dict(key)
            data(3) = data(3) + q
            data(4) = data(4) + bal
            dict(key) = data
        Else
            dict.Add key, Array(shortPO, orderNo, item, q, bal)
        End If
        totalQ = totalQ + q
        totalBal = totalBal + bal
NextRow:
    Next r
    If dict.Count = 0 Then Err.Raise vbObjectError + 805, , "������ �� �����Ͱ� �����ϴ�."
    baseName = "�����ܷ�_���ֺ�"
    outName = baseName
    Do
        exists = False
        For Each sh In wb.Sheets
            If sh.Name = outName Then exists = True: Exit For
        Next sh
        If Not exists Then Exit Do
        suffix = suffix + 1
        outName = baseName & "_" & suffix
    Loop
    Set outWs = wb.Worksheets.Add(After:=wb.Sheets(wb.Sheets.Count))
    outWs.Name = outName
    outWs.Range("A1:E1").Value = Array("���ֹ�ȣ ��5�ڸ�", "���ֹ�ȣ", "ǰ���", "���ּ���", "�̳�����")
    outWs.Columns("A:C").NumberFormat = "@"
    r = 2
    For Each k In dict.Keys
        data = dict(k)
        For j = 0 To 4
            outWs.Cells(r, j + 1).Value2 = data(j)
        Next j
        r = r + 1
    Next k
    If r > 3 Then outWs.Range("A1:E" & (r - 1)).Sort Key1:=outWs.Range("A2"), Order1:=xlAscending, Key2:=outWs.Range("B2"), Order2:=xlAscending, Key3:=outWs.Range("C2"), Order3:=xlAscending, Header:=xlYes
    outWs.Cells(r, 3).Value2 = "�հ�"
    outWs.Cells(r, 4).Value2 = totalQ
    outWs.Cells(r, 5).Value2 = totalBal
    With outWs.Range("A1:E" & r)
        .Font.Name = "���� ����"
        .Font.Size = 11
        .Font.Color = vbBlack
        .VerticalAlignment = xlCenter
        .WrapText = False
        .RowHeight = 23
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(190, 190, 190)
        .Borders.Weight = xlThin
    End With
    With outWs.Range("A1:E1")
        .Font.Bold = True
        .Interior.Color = RGB(230, 230, 230)
        .HorizontalAlignment = xlCenter
        .RowHeight = 30
    End With
    With outWs.Range("A" & r & ":E" & r)
        .Font.Bold = True
        .Interior.Color = RGB(230, 230, 230)
    End With
    outWs.Columns("A").ColumnWidth = 18
    outWs.Columns("B").ColumnWidth = 26
    outWs.Columns("C").ColumnWidth = 36
    outWs.Columns("D:E").ColumnWidth = 17
    outWs.Range("C2:C" & r).ShrinkToFit = True
    outWs.Range("D2:E" & r).NumberFormat = "#,##0.########;-#,##0.########;0"
    outWs.Range("A1:E" & (r - 1)).AutoFilter
    With outWs.PageSetup
        .PaperSize = xlPaperA4
        .Orientation = xlLandscape
        .Zoom = False
        .FitToPagesWide = 1
        .FitToPagesTall = False
        .BlackAndWhite = True
        .PrintTitleRows = "$1:$1"
        .PrintArea = outWs.Range("A1:E" & r).Address
        .CenterHorizontally = True
        .CenterFooter = "&P / &N"
    End With
    MsgBox "�����ܷ� ���� �Ϸ�: " & outName & vbCrLf & "���ּ���: " & Format(totalQ, "#,##0.########") & vbCrLf & "�̳�����: " & Format(totalBal, "#,##0.########"), vbInformation
    Exit Sub
Failed:
    MsgBox Err.Description, vbExclamation
End Sub

Private Function HeaderKey(ByVal v As Variant) As String
    If IsError(v) Then Exit Function
    HeaderKey = Replace(Replace(Replace(Replace(Replace(Trim$(CStr(v)), " ", ""), vbCr, ""), vbLf, ""), vbTab, ""), ChrW(160), "")
End Function
Private Function TextValue(ByVal v As Variant, ByVal rowNo As Long) As String
    If IsError(v) Then Err.Raise vbObjectError + 806, , "���� ���� �ֽ��ϴ�. ���� ��: " & rowNo
    TextValue = Trim$(CStr(v))
End Function
Private Function QuantityValue(ByVal v As Variant, ByVal rowNo As Long) As Double
    If IsError(v) Then Err.Raise vbObjectError + 807, , "���� ���� ���� �ֽ��ϴ�. ���� ��: " & rowNo
    If Not IsNumeric(v) Then Err.Raise vbObjectError + 808, , "������ ���ڰ� �ƴմϴ�. ���� ��: " & rowNo
    QuantityValue = CDbl(v)
End Function
Private Function IsTotalRow(ByVal ws As Worksheet, ByVal r As Long) As Boolean
    Dim c As Long, s As String
    For c = 1 To ws.Cells(r, ws.Columns.Count).End(xlToLeft).Column
        s = HeaderKey(ws.Cells(r, c).Value2)
        Select Case UCase$(s)
            Case "�հ�", "���հ�", "��", "TOTAL", "GRANDTOTAL"
                IsTotalRow = True
                Exit Function
        End Select
    Next c
End Function
