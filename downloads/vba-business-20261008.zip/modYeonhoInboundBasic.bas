Attribute VB_Name = "modYeonhoInboundBasic"
Option Explicit
Sub ��ȣ����()
    ' --- ��� ���� ���� (Option Explicit ����) ---
    Dim wsERP As Worksheet, wsShip As Worksheet, wsAir As Worksheet, wsMaster As Worksheet, wsFinal As Worksheet
    Dim vERP As Variant, vShip As Variant, vAir As Variant, vMaster As Variant
    Dim dictMaster As Object, dictERP As Object, dictUrgent As Object, dictColor As Object
    Dim dictShipDemand As Object, dictAirDemand As Object, dictIncoming As Object
    Dim dictStatus As Object, dictPrettyName As Object, dictRawDaea As Object
    Dim dictBalance As Object ' ���� BALANCE �ָӴ�
    Dim dictDemandKeys As Object, shipKeys As Object, airOnlyKeys As Object
    Dim i As Long, outRow As Long, lastRow As Long
    Dim fac As String, rawName As String, cleanKey As String, yName As String, keyStr As String
    Dim arrears As Double, incomingQty As Double, totalDemand As Double
    Dim shipNeed As Double, airNeed As Double, finalOrderQty As Double, k As Variant
    Dim cleanYName As String, cleanERPName As String, statusVal As String, qVal As Double
    Dim dIdx As Integer, combinedKeys As Variant, remainNeed As Double, appliedUrgent As Double, uStock As Double
    ' 1. ��Ʈ ����
    On Error Resume Next
    Set wsERP = Sheets("��ȣ ERP"): Set wsShip = Sheets("����"): Set wsAir = Sheets("Air"): Set wsMaster = LoadYeonhoNewMaster()
    On Error GoTo 0
    If wsMaster Is Nothing Or wsERP Is Nothing Or wsShip Is Nothing Or wsAir Is Nothing Then
        MsgBox "��Ʈ �̸��� Ȯ�����ּ���. (��ȣ ERP, ����, Air �� �ܺ� NEW ������ �ʿ�)", vbCritical
        Exit Sub
    End If
    ' Dictionary ��ü �ʱ�ȭ
    Set dictMaster = CreateObject("Scripting.Dictionary")
    Set dictERP = CreateObject("Scripting.Dictionary")
    Set dictUrgent = CreateObject("Scripting.Dictionary")
    Set dictShipDemand = CreateObject("Scripting.Dictionary")
    Set dictAirDemand = CreateObject("Scripting.Dictionary")
    Set dictDemandKeys = CreateObject("Scripting.Dictionary")
    Set dictIncoming = CreateObject("Scripting.Dictionary")
    Set dictColor = CreateObject("Scripting.Dictionary")
    Set dictStatus = CreateObject("Scripting.Dictionary")
    Set dictPrettyName = CreateObject("Scripting.Dictionary")
    Set dictRawDaea = CreateObject("Scripting.Dictionary")
    Set dictBalance = CreateObject("Scripting.Dictionary")
    Set shipKeys = CreateObject("Scripting.Dictionary")
    Set airOnlyKeys = CreateObject("Scripting.Dictionary")
    ' 2. [������] �ε�
    lastRow = wsMaster.Cells(wsMaster.Rows.Count, "B").End(-4162).Row
    If lastRow >= 2 Then
        vMaster = wsMaster.Range("A1:B" & lastRow).value
        For i = 2 To UBound(vMaster, 1)
            rawName = CStr(vMaster(i, 2))
            If Trim(rawName) <> "" Then
                cleanKey = GetPerfectCleanKey(rawName)
                dictMaster(cleanKey) = Trim(CStr(vMaster(i, 1)))
                If wsMaster.Cells(i, 2).Interior.ColorIndex <> -4142 Then
                    dictColor(GetPerfectCleanKey(dictMaster(cleanKey))) = wsMaster.Cells(i, 2).Interior.Color
                End If
            End If
        Next i
    End If
    ' 3. [��ȣ ERP] ��� �ε�
    lastRow = wsERP.Cells(wsERP.Rows.Count, "A").End(-4162).Row
    If lastRow >= 2 Then
        vERP = wsERP.Range("A1:C" & lastRow).value
        For i = 2 To UBound(vERP, 1)
            cleanERPName = GetPerfectCleanKey(CStr(vERP(i, 1)))
            fac = "": If UBound(vERP, 2) >= 3 Then fac = GetFacCodeFinal(CStr(vERP(i, 3)))
            qVal = 0: If UBound(vERP, 2) >= 2 Then qVal = Val(Replace(CStr(vERP(i, 2)), ",", ""))
            If fac = "���" Then
                dictUrgent(cleanERPName) = dictUrgent(cleanERPName) + qVal
            ElseIf fac <> "" Then
                dictERP(fac & "|" & cleanERPName) = dictERP(fac & "|" & cleanERPName) + qVal
            End If
        Next i
    End If
    ' 4. [����] �ε� (BALANCE: F��)
    lastRow = wsShip.Cells(wsShip.Rows.Count, "C").End(-4162).Row
    If lastRow >= 2 Then
        vShip = wsShip.Range("A1:F" & lastRow).value
        For i = 2 To UBound(vShip, 1)
            rawName = CStr(vShip(i, 3))
            If Trim(rawName) <> "" Then
                fac = GetFacCodeFinal(CStr(vShip(i, 1)))
                cleanKey = GetPerfectCleanKey(rawName)
                If dictMaster.exists(cleanKey) Then
                    yName = dictMaster(cleanKey): statusVal = "��Ī�Ϸ�"
                Else
                    yName = rawName: statusVal = "�̵��"
                End If
                cleanYName = GetPerfectCleanKey(yName)
                keyStr = fac & "|" & cleanYName
                dictShipDemand(keyStr) = dictShipDemand(keyStr) + Val(Replace(CStr(vShip(i, 4)), ",", ""))
                dictIncoming(keyStr) = dictIncoming(keyStr) + Val(Replace(CStr(vShip(i, 5)), ",", ""))
                ' BALANCE ���� ���� (���� ��Ʈ �켱)
                If UBound(vShip, 2) >= 6 Then
                    qVal = Val(Replace(CStr(vShip(i, 6)), ",", ""))
                    If qVal <> 0 Then dictBalance(keyStr) = qVal
                End If
                shipKeys(keyStr) = True: dictDemandKeys(keyStr) = True
                dictStatus(keyStr) = statusVal
                dictPrettyName(keyStr) = Trim(Replace(Replace(yName, "(YEONHO)", ""), "YEONHO", ""))
                If Not dictRawDaea.exists(keyStr) Then dictRawDaea(keyStr) = rawName
            End If
        Next i
    End If
    ' 5. [Air] �ε� (BALANCE: E��)
    lastRow = wsAir.Cells(wsAir.Rows.Count, "C").End(-4162).Row
    If lastRow >= 2 Then
        vAir = wsAir.Range("A1:E" & lastRow).value
        For i = 2 To UBound(vAir, 1)
            rawName = CStr(vAir(i, 3))
            If Trim(rawName) <> "" Then
                fac = GetFacCodeFinal(CStr(vAir(i, 1)))
                cleanKey = GetPerfectCleanKey(rawName)
                If dictMaster.exists(cleanKey) Then
                    yName = dictMaster(cleanKey): statusVal = "��Ī�Ϸ�"
                Else
                    yName = rawName: statusVal = "�̵��"
                End If
                cleanYName = GetPerfectCleanKey(yName)
                keyStr = fac & "|" & cleanYName
                dictAirDemand(keyStr) = dictAirDemand(keyStr) + Val(Replace(CStr(vAir(i, 4)), ",", ""))
                ' BALANCE ���� ���� (���ڿ� ������ ��� ����)
                If UBound(vAir, 2) >= 5 Then
                    qVal = Val(Replace(CStr(vAir(i, 5)), ",", ""))
                    If qVal <> 0 Then dictBalance(keyStr) = qVal
                End If
                If Not shipKeys.exists(keyStr) Then airOnlyKeys(keyStr) = True
                dictDemandKeys(keyStr) = True
                If Not dictStatus.exists(keyStr) Then dictStatus(keyStr) = statusVal
                If Not dictPrettyName.exists(keyStr) Then dictPrettyName(keyStr) = Trim(Replace(Replace(yName, "(YEONHO)", ""), "YEONHO", ""))
                If Not dictRawDaea.exists(keyStr) Then dictRawDaea(keyStr) = rawName
            End If
        Next i
    End If
    ' 6. ��� ��Ʈ ���� (A~I�� ����)
    On Error Resume Next
    Set wsFinal = Sheets("��������"): If wsFinal Is Nothing Then Set wsFinal = Sheets.Add(After:=Sheets(Sheets.Count)): wsFinal.Name = "��������"
    wsFinal.Cells.Clear: On Error GoTo 0
    ' [��ü ���� 1] ��Ʈ ��ü �۲�, ũ��, ������ ����
    With wsFinal.Cells.Font
        .Name = "Calibri"
        .Size = 11
        .Color = RGB(0, 0, 0)
    End With
    wsFinal.Range("A1:I1").value = Array("FAC", "ǰ��", "����", "AIR", "�ʿ���", "������", "��ȣ���", "�����ʿ䷮", "�߶���")
    outRow = 2
    ' 7. ���� ���
    combinedKeys = Array(shipKeys, airOnlyKeys)
    For dIdx = 0 To 1
        For Each k In combinedKeys(dIdx).keys
            fac = Split(CStr(k), "|")(0): cleanYName = Split(CStr(k), "|")(1)
            shipNeed = dictShipDemand(k): airNeed = dictAirDemand(k)
            totalDemand = shipNeed + airNeed: incomingQty = dictIncoming(k): arrears = dictERP(k)
            remainNeed = totalDemand - incomingQty - arrears: If remainNeed < 0 Then remainNeed = 0
            ' ��� ���� ����
            appliedUrgent = 0
            If remainNeed > 0 Then
                If dictUrgent.exists(cleanYName) Then
                    uStock = dictUrgent(cleanYName)
                    If uStock >= remainNeed Then
                        appliedUrgent = remainNeed
                        dictUrgent(cleanYName) = uStock - remainNeed
                    Else
                        appliedUrgent = uStock
                        dictUrgent(cleanYName) = 0
                    End If
                End If
            End If
            finalOrderQty = remainNeed - appliedUrgent: If finalOrderQty < 0 Then finalOrderQty = 0
            ' �� �Է�
            wsFinal.Cells(outRow, 1).value = fac              ' A��: FAC
            wsFinal.Cells(outRow, 2).value = dictRawDaea(k)   ' B��: ǰ��(����)
            wsFinal.Cells(outRow, 3).value = shipNeed         ' C��: ����
            wsFinal.Cells(outRow, 4).value = airNeed          ' D��: AIR
            wsFinal.Cells(outRow, 5).value = totalDemand      ' E��: �ʿ���
            wsFinal.Cells(outRow, 6).value = incomingQty      ' F��: ������
            wsFinal.Cells(outRow, 7).value = arrears          ' G��: ��ȣ���
            wsFinal.Cells(outRow, 8).value = finalOrderQty    ' H��: �����ʿ䷮
            wsFinal.Cells(outRow, 9).value = dictBalance(k)   ' I��: �߶���
            ' [����] �͹̳�(�����Ϳ��� ������ �ִ� ǰ��) ����: ���� ��Ȳ��(#FFA500), ��� ��Ʈ ����(��������)
            If dictColor.exists(cleanYName) Then
                With wsFinal.Cells(outRow, 8)
                    .Interior.Color = RGB(255, 165, 0)
                    .Font.Bold = True
                End With
            End If
            ' ������ + ��ȣ��Ⱑ AIR �������� ������ �����ʿ䷮(H��)�� ��Ʈ�� ������(#FF0000) �� ����ü�� �����
            If (incomingQty + arrears) < airNeed Then
                With wsFinal.Cells(outRow, 8)
                    .Font.Color = RGB(255, 0, 0)
                    .Font.Bold = True
                End With
            End If
            outRow = outRow + 1
        Next k
    Next dIdx
    ' [��ü ���� 2] C��~I�� 1,000���� �޸� ����
    If outRow > 2 Then
        wsFinal.Range("C2:I" & outRow - 1).NumberFormat = "#,##0"
    End If
    wsFinal.Columns.AutoFit
    MsgBox "���� ���� �� ���Ǻ� �۲� ���� ������ �Ϸ�Ǿ����ϴ�!", vbInformation
End Sub
' --- ���� �Լ�: ��ô ---
Function GetPerfectCleanKey(ByVal v As Variant) As String
    Dim s As String: s = UCase(Trim(CStr(v)))
    s = Replace(s, "(YEONHO)", ""): s = Replace(s, "YEONHO", "")
    s = Replace(s, "RED", "RE"): s = Replace(s, "GRN", "GN"): s = Replace(s, "BLU", "BL"): s = Replace(s, "YEL", "YE")
    s = Replace(s, "WHT", ""): s = Replace(s, "WH", "")
    s = Replace(s, " ", ""): s = Replace(s, "-", ""): s = Replace(s, "(", ""): s = Replace(s, ")", ""): s = Replace(s, "[", ""): s = Replace(s, "]", ""): s = Replace(s, "/", ""): s = Replace(s, ".", "")
    GetPerfectCleanKey = s
End Function
' --- ���� �Լ�: ���� ���� ---
Function GetFacCodeFinal(ByVal v As String) As String
    Dim s As String: s = UCase(Trim(v))
    If InStr(s, "���") > 0 Then
        GetFacCodeFinal = "���"
    ElseIf InStr(s, "F1") > 0 Then
        GetFacCodeFinal = "F1"
    ElseIf InStr(s, "F2") > 0 Then
        GetFacCodeFinal = "F2"
    ElseIf InStr(s, "F5") > 0 Then
        GetFacCodeFinal = "F5"
    Else
        GetFacCodeFinal = s
    End If
End Function

Private Function LoadYeonhoNewMaster() As Worksheet
    Dim targetBook As Workbook, targetSheet As Object, book As Workbook, masterBook As Workbook
    Dim sourcePath As String, picked As Variant, openedHere As Boolean, oldEvents As Boolean
    Dim result As Worksheet, message As String
    On Error GoTo Failed
    Set targetBook = ActiveWorkbook
    Set targetSheet = ActiveSheet
    oldEvents = Application.EnableEvents
    sourcePath = Environ("USERPROFILE") & "\OneDrive - Dae-A Electronics (Thailand) Company Limited\���� ȭ��\��ȣ ������ ��Ʈ NEW.xlsx"
    For Each book In Application.Workbooks
        If StrComp(book.FullName, sourcePath, vbTextCompare) = 0 Then Set masterBook = book: Exit For
    Next book
    If masterBook Is Nothing Then
        If Dir(sourcePath) = "" Then
            picked = Application.GetOpenFilename("Excel Workbook (*.xlsx),*.xlsx", , "��ȣ ������ ��Ʈ NEW.xlsx�� �����ϼ���")
            If VarType(picked) = vbBoolean Then GoTo RestoreTarget
            sourcePath = CStr(picked)
            For Each book In Application.Workbooks
                If StrComp(book.FullName, sourcePath, vbTextCompare) = 0 Then Set masterBook = book: Exit For
            Next book
        End If
        If masterBook Is Nothing Then
            Application.EnableEvents = False
            Set masterBook = Application.Workbooks.Open(Filename:=sourcePath, UpdateLinks:=0, ReadOnly:=True)
            openedHere = True
        End If
    End If
    Set result = masterBook.Worksheets("������")
    If result.Cells(result.Rows.Count, 1).End(xlUp).Row < 2 Then Err.Raise vbObjectError + 910, , "������ A���� ǰ�� �����Ͱ� �����ϴ�."
    If result.Cells(result.Rows.Count, 2).End(xlUp).Row < 2 Then Err.Raise vbObjectError + 911, , "������ B���� ǰ�� �����Ͱ� �����ϴ�."
    Set LoadYeonhoNewMaster = result
RestoreTarget:
    On Error Resume Next
    Application.EnableEvents = False
    If Not targetBook Is Nothing Then targetBook.Activate
    If Not targetSheet Is Nothing Then targetSheet.Activate
    Application.EnableEvents = oldEvents
    Exit Function
Failed:
    message = "�� ��ȣ �����͸� ���� ���߽��ϴ�: " & sourcePath & vbCrLf & Err.Description
    On Error Resume Next
    If openedHere Then masterBook.Close SaveChanges:=False
    MsgBox message, vbExclamation
    GoTo RestoreTarget
End Function
